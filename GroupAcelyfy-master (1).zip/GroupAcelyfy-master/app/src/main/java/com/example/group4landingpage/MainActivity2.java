package com.example.group4landingpage;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
       TextView text1 = (TextView) findViewById(R.id.textView22);
        TextView text2 = (TextView) findViewById(R.id.textView4);
        TextView text3 = (TextView) findViewById(R.id.textView5);
        TextView text4 = (TextView) findViewById(R.id.textView6);
        TextView text5 = (TextView) findViewById(R.id.textView8);
        TextView text6 = (TextView) findViewById(R.id.textView7);
        TextView text7 = (TextView) findViewById(R.id.textView9);
        TextView text8 = (TextView) findViewById(R.id.textView10);
        TextView text9 = (TextView) findViewById(R.id.textView27);
        TextView text10 = (TextView) findViewById(R.id.textView28);
        TextView text11= (TextView) findViewById(R.id.textView29);
        TextView text12= (TextView) findViewById(R.id.textView30);
        TextView text13 = (TextView) findViewById(R.id.textView31);
        TextView text14 = (TextView) findViewById(R.id.textView32);
        TextView text15 = (TextView) findViewById(R.id.textView33);
        TextView text16 = (TextView) findViewById(R.id.textView12);
        text1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent int1 = new Intent(MainActivity2.this,MainActivity3.class);
                startActivity(int1);
            }
        });

    text2.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            Intent int2 = new Intent(MainActivity2.this,MainActivity4.class);
            startActivity(int2);
        }
    });
        text3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent int3 = new Intent(MainActivity2.this,MainActivity5.class);
                startActivity(int3);
            }
        });
        text4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent int4 = new Intent(MainActivity2.this,MainActivity6.class);
                startActivity(int4);
            }
        });
        text5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent int5 = new Intent(MainActivity2.this,MainActivity7.class);
                startActivity(int5);
            }
        });
        text6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent int6 = new Intent(MainActivity2.this,MainActivity8.class);
                startActivity(int6);
            }
        });
        text7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent int7 = new Intent(MainActivity2.this,MainActivity9.class);
                startActivity(int7);
            }
        });
        text8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent int8 = new Intent(MainActivity2.this,MainActivity10.class);
                startActivity(int8);
            }
        });
        text9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent int9 = new Intent(MainActivity2.this,MainActivity11.class);
                startActivity(int9);
            }
        });
        text10.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent int10 = new Intent(MainActivity2.this,MainActivity12.class);
                startActivity(int10);
            }
        });
        text11.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent int11 = new Intent(MainActivity2.this,MainActivity13.class);
                startActivity(int11);
            }
        });
        text12.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent int12 = new Intent(MainActivity2.this,MainActivity14.class);
                startActivity(int12);
            }
        });
        text13.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent int13 = new Intent(MainActivity2.this,MainActivity15.class);
                startActivity(int13);
            }
        });
        text14.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent int14 = new Intent(MainActivity2.this,MainActivity16.class);
                startActivity(int14);
            }
        });
        text15.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent int15 = new Intent(MainActivity2.this,MainActivity17.class);
                startActivity(int15);
            }
        });
        text16.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent int16 = new Intent(MainActivity2.this,MainActivity18.class);
                startActivity(int16);
            }
        });
    }
}